﻿using System;
using System.ComponentModel.DataAnnotations;

public class Claim
{
    public int Id { get; set; }
    public string LecturerName { get; set; }
    public int HoursWorked { get; set; }
    public decimal HourlyRate { get; set; }
    public string Notes { get; set; }
    public string Status { get; set; } = "Pending"; // Initial status is "Pending"
    public DateTime SubmissionDate { get; set; } = DateTime.Now;
    public string FilePath { get; internal set; }
}
public string FilePath { get; set; } // Path to the uploaded file
