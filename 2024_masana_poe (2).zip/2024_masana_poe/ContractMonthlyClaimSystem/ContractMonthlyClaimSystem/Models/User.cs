﻿namespace ContractMonthlyClaimSystem.Web.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Role { get; set; } // e.g., Lecturer, Coordinator, Manager
    }
}

