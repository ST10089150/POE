﻿namespace ContractMonthlyClaimSystem.Models
{
    public class Startup
    {
    }
}
