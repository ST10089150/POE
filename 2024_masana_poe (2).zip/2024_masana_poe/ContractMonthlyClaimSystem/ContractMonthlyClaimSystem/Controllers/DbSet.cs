﻿namespace ContractMonthlyClaimSystem.Web.Data
{
    public class DbSet<T>
    {
    }
}