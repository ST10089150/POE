﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using System.IO;
using System.Threading.Tasks;

namespace YourNamespace.Controllers
{
    public class ClaimController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClaimController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Claim/Index
        public async Task<IActionResult> Index()
        {
            var claims = await _context.Claims.ToListAsync(); // Fetch all claims
            return View(claims); // Return to the view with all claims
        }

        // POST: Claim/Create (Standard Claim Creation without File Upload)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("LecturerName,HoursWorked,HourlyRate,Notes")] Claim claim)
        {
            if (ModelState.IsValid)
            {
                _context.Add(claim); // Add the claim to the context
                await _context.SaveChangesAsync(); // Save changes to the database
                return RedirectToAction(nameof(Index)); // Redirect to the index view
            }
            return View(claim); // If not valid, return to the create form
        }

        // POST: Claim/CreateWithFile (Claim Creation with File Upload)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateWithFile(Claim claim, IFormFile uploadedFile)
        {
            if (ModelState.IsValid)
            {
                // Handle file upload
                if (uploadedFile != null && uploadedFile.Length > 0)
                {
                    var fileName = Path.GetFileName(uploadedFile.FileName);
                    var uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");

                    // Ensure "uploads" directory exists
                    Directory.CreateDirectory(uploadPath);

                    var filePath = Path.Combine(uploadPath, fileName);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await uploadedFile.CopyToAsync(fileStream); // Save the file to disk
                    }

                    claim.FilePath = $"/uploads/{fileName}"; // Save the file path relative to wwwroot
                }

                _context.Add(claim); // Add the claim to the database
                await _context.SaveChangesAsync(); // Save changes
                return RedirectToAction(nameof(Index)); // Redirect to index view
            }
            return View("Create", claim); // If invalid, return to create view
        }

        // POST: Claim/Approve
        [HttpPost]
        public async Task<IActionResult> Approve(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim != null)
            {
                claim.Status = "Approved"; // Set status to Approved
                _context.Update(claim);
                await _context.SaveChangesAsync(); // Save changes to database
            }
            return RedirectToAction(nameof(Index)); // Redirect to index view
        }

        // POST: Claim/Reject
        [HttpPost]
        public async Task<IActionResult> Reject(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim != null)
            {
                claim.Status = "Rejected"; // Set status to Rejected
                _context.Update(claim);
                await _context.SaveChangesAsync(); // Save changes to database
            }
            return RedirectToAction(nameof(Index)); // Redirect to index view
        }
    }
}
