﻿namespace ContractMonthlyClaimSystem.Web.Data
{
    public class DbContextOptions<T>
    {
    }
}