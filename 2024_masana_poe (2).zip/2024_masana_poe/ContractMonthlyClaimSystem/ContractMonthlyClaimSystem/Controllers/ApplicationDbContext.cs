﻿using ContractMonthlyClaimSystem.Web.Models;
using System.Collections.Generic;
using System.Security.Claims;

namespace ContractMonthlyClaimSystem.Web.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { }

        public DbSet<Claim> Claims { get; set; }
        public DbSet<User> Users { get; set; }
    }
}