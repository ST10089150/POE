﻿using System.ComponentModel.DataAnnotations;

public class Claim
{
    public int Id { get; set; }
    public string LecturerName { get; set; }
    public double HoursWorked { get; set; }
    public double HourlyRate { get; set; }
    public string Notes { get; set; }
    public string Status { get; set; } = "Pending";
    public string Approver { get; set; }
    public DateTime SubmissionDate { get; set; } = DateTime.Now;

    // New field for file storage
    public string SupportingDocumentPath { get; set; }
}
string Status { get; set; } = "Pending";

// For progress bar representation
public int Progress
{
    get
    {
        return Status switch
        {
            "Pending" => 33,
            "Approved" => 100,
            "Rejected" => 0,
            _ => 0,
        };
    }
}
public string Status { get; set; } = "Pending";

// For progress bar representation
public int Progress
{
    get
    {
        return Status switch
        {
            "Pending" => 33,
            "Approved" => 100,
            "Rejected" => 0,
            _ => 0,
        };
    }
}
using System.ComponentModel.DataAnnotations;

public class Claim
{
    public int Id { get; set; }

    [Required]
    [StringLength(100, ErrorMessage = "Name is required and cannot exceed 100 characters.")]
    public string LecturerName { get; set; }

    [Required]
    [Range(1, 1000, ErrorMessage = "Hours worked must be between 1 and 1000.")]
    public double HoursWorked { get; set; }

    [Required]
    [Range(10, 500, ErrorMessage = "Hourly rate must be between $10 and $500.")]
    public double HourlyRate { get; set; }

    public string Notes { get; set; }
    public string Status { get; set; } = "Pending";
}
using System.ComponentModel.DataAnnotations;

public class Claim
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Lecturer name is required.")]
    [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters.")]
    public string LecturerName { get; set; }

    [Required(ErrorMessage = "Hours worked is required.")]
    [Range(1, 1000, ErrorMessage = "Hours worked must be between 1 and 1000.")]
    public double HoursWorked { get; set; }

    [Required(ErrorMessage = "Hourly rate is required.")]
    [Range(10, 500, ErrorMessage = "Hourly rate must be between $10 and $500.")]
    public double HourlyRate { get; set; }

    [Display(Name = "Total Payment")]
    public double TotalPayment => HoursWorked * HourlyRate;

    [StringLength(500, ErrorMessage = "Notes cannot exceed 500 characters.")]
    public string Notes { get; set; }

    public string Status { get; set; } = "Pending";
}




