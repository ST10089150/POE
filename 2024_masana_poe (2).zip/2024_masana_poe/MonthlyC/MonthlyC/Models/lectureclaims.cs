﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

public IActionResult ManageLecturerClaims(int id)
{
    var lecturer = _context.Lecturers.Include(l => l.Claims).FirstOrDefault(l => l.Id == id);
    if (lecturer == null)
    {
        return NotFound();
    }

    return View(lecturer);
}
//
public class Lecturer
{
    public int Id { get; set; }

    [Required]
    [StringLength(100)]
    public string Name { get; set; }

    [Required]
    [StringLength(50)]
    public string Department { get; set; }

    public ICollection<Claim> Claims { get; set; }
}
