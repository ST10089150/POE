﻿public static void SeedDatabase(AppDbContext context)
{
    if (!context.Claims.Any())
    {
        context.Claims.AddRange(
            new Claim { LecturerName = "John Doe", HoursWorked = 25, HourlyRate = 50, Status = "Pending" },
            new Claim { LecturerName = "Jane Smith", HoursWorked = 20, HourlyRate = 40, Status = "Pending" }
        );
        context.SaveChanges();
    }
}
