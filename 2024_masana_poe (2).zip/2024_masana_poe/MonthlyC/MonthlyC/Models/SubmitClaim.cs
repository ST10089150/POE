﻿using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System;
@model Claim

<h2>Submit Claim</h2>

<form asp-action= "SubmitClaim" method= "post" id= "claimForm" >
    < div class= "form-group" >
        < label for= "LecturerName" > Lecturer Name </ label >
        < input asp -for= "LecturerName" class= "form-control" placeholder = "Enter your name" />
        < span asp - validation -for= "LecturerName" class= "text-danger" ></ span >
    </ div >

    < div class= "form-group" >
        < label for= "HoursWorked" > Hours Worked </ label >
        < input asp -for= "HoursWorked" id = "hoursWorked" type = "number" class= "form-control" min = "0" placeholder = "e.g., 20" />
        < span asp - validation -for= "HoursWorked" class= "text-danger" ></ span >
    </ div >

    < div class= "form-group" >
        < label for= "HourlyRate" > Hourly Rate </ label >
        < input asp -for= "HourlyRate" id = "hourlyRate" type = "number" class= "form-control" min = "0" placeholder = "e.g., 50" />
        < span asp - validation -for= "HourlyRate" class= "text-danger" ></ span >
    </ div >

    < div class= "form-group" >
        < label for= "TotalPayment" > Total Payment </ label >
        < input id = "totalPayment" type = "text" class= "form-control" readonly />
    </ div >

    < div class= "form-group" >
        < label for= "Notes" > Notes </ label >
        < textarea asp -for= "Notes" class= "form-control" placeholder = "Add any additional details..." ></ textarea >
        < span asp - validation -for= "Notes" class= "text-danger" ></ span >
    </ div >

    < button type = "submit" class= "btn btn-primary mt-3" > Submit Claim </ button >
</ form >

< script src = "https://code.jquery.com/jquery-3.6.0.min.js" ></ script >
< script >
    $(document).ready(function() {
    function calculateTotal()
    {
        const hours = parseFloat($("#hoursWorked").val()) || 0;
        const rate = parseFloat($("#hourlyRate").val()) || 0;
        const total = hours * rate;
            $("#totalPayment").val(total.toFixed(2)); // Update total payment field
    }

        // Trigger calculation on input changes
        $("#hoursWorked, #hourlyRate").on("input", calculateTotal);
});
</ script >


