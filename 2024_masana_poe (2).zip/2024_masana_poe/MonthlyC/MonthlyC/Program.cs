using Microsoft.AspNetCore.Mvc;

namespace MonthlyC
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddSignalR();

app.MapHub<ClaimStatusHub>("/claimStatusHub");
//Controller Methods for Batch Actions
[HttpPost]
public IActionResult ProcessClaims(int[] claimIds)
{
    var claims = _context.Claims.Where(c => claimIds.Contains(c.Id) && c.Status == "Pending").ToList();

    foreach (var claim in claims)
    {
        claim.Status = "Approved";
    }

    _context.SaveChanges();
    TempData["Message"] = "Selected claims approved successfully!";
    return RedirectToAction("HRDashboard");
}

[HttpPost]
public IActionResult RejectClaims(int[] claimIds)
{
    var claims = _context.Claims.Where(c => claimIds.Contains(c.Id) && c.Status == "Pending").ToList();

    foreach (var claim in claims)
    {
        claim.Status = "Rejected";
    }

    _context.SaveChanges();
    TempData["Message"] = "Selected claims rejected successfully!";
    return RedirectToAction("HRDashboard");
}
//
public IActionResult AddLecturer()
{
    return View(new Lecturer());
}

[HttpPost]
public IActionResult AddLecturer(Lecturer lecturer)
{
    if (ModelState.IsValid)
    {
        _context.Lecturers.Add(lecturer);
        _context.SaveChanges();
        return RedirectToAction("HRDashboard");
    }
    return View(lecturer);
}

public IActionResult EditLecturer(int id)
{
    var lecturer = _context.Lecturers.Find(id);
    if (lecturer == null)
    {
        return NotFound();
    }
    return View(lecturer);
}

[HttpPost]
public IActionResult EditLecturer(Lecturer lecturer)
{
    if (ModelState.IsValid)
    {
        _context.Lecturers.Update(lecturer);
        _context.SaveChanges();
        return RedirectToAction("HRDashboard");
    }
    return View(lecturer);
}

[HttpPost]
public IActionResult DeleteLecturer(int id)
{
    var lecturer = _context.Lecturers.Find(id);
    if (lecturer != null)
    {
        _context.Lecturers.Remove(lecturer);
        _context.SaveChanges();
    }
    return RedirectToAction("HRDashboard");
}


