﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;

public class ClaimsController : Controller
{
    private readonly AppDbContext _context;
    private readonly IWebHostEnvironment _environment;

    public ClaimsController(AppDbContext context, IWebHostEnvironment environment)
    {
        _context = context;
        _environment = environment;
    }

    public IActionResult SubmitClaim()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> SubmitClaim(Claim claim, IFormFile supportingDocument)
    {
        if (ModelState.IsValid)
        {
            // File upload handling
            if (supportingDocument != null)
            {
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
                Directory.CreateDirectory(uploadsFolder); // Ensure the directory exists

                string uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(supportingDocument.FileName);
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await supportingDocument.CopyToAsync(fileStream);
                }

                claim.SupportingDocumentPath = "/uploads/" + uniqueFileName;
            }

            _context.Claims.Add(claim);
            await _context.SaveChangesAsync();

            return RedirectToAction("ViewClaims");
        }
        return View(claim);
    }

public IActionResult DownloadFile(string filePath)
{
    if (string.IsNullOrWhiteSpace(filePath))
        return NotFound();

    string fullPath = Path.Combine(_environment.WebRootPath, filePath);
    if (System.IO.File.Exists(fullPath))
    {
        byte[] fileBytes = System.IO.File.ReadAllBytes(fullPath);
        string fileName = Path.GetFileName(fullPath);
        return File(fileBytes, "application/octet-stream", fileName);
    }
    return NotFound();
}
    //
    public class ClaimsController : Controller
    {
        private readonly AppDbContext _context;

        public ClaimsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult VerifyClaims()
        {
            var pendingClaims = _context.Claims.Where(c => c.Status == "Pending").ToList();
            return View(pendingClaims);
        }

        [HttpPost]
        public JsonResult ApproveClaim(int id)
        {
            var claim = _context.Claims.FirstOrDefault(c => c.Id == id);
            if (claim != null && claim.Status == "Pending")
            {
                claim.Status = "Approved";
                _context.SaveChanges();
                return Json(new { success = true, message = "Claim approved successfully!" });
            }

            return Json(new { success = false, message = "Claim could not be approved." });
        }

        [HttpPost]
        public JsonResult RejectClaim(int id)
        {
            var claim = _context.Claims.FirstOrDefault(c => c.Id == id);
            if (claim != null && claim.Status == "Pending")
            {
                claim.Status = "Rejected";
                _context.SaveChanges();
                return Json(new { success = true, message = "Claim rejected successfully!" });
            }

            return Json(new { success = false, message = "Claim could not be rejected." });
        }
    }
    public IActionResult HRDashboard()
    {
        var lecturers = _context.Lecturers.Include(l => l.Claims).ToList();
        return View(lecturers);
    }
    // Controller Methods for Batch Actions
    [HttpPost]
    public IActionResult ProcessClaims(int[] claimIds)
    {
        var claims = _context.Claims.Where(c => claimIds.Contains(c.Id) && c.Status == "Pending").ToList();

        foreach (var claim in claims)
        {
            claim.Status = "Approved";
        }

        _context.SaveChanges();
        TempData["Message"] = "Selected claims approved successfully!";
        return RedirectToAction("HRDashboard");
    }

    [HttpPost]
    public IActionResult RejectClaims(int[] claimIds)
    {
        var claims = _context.Claims.Where(c => claimIds.Contains(c.Id) && c.Status == "Pending").ToList();

        foreach (var claim in claims)
        {
            claim.Status = "Rejected";
        }

        _context.SaveChanges();
        TempData["Message"] = "Selected claims rejected successfully!";
        return RedirectToAction("HRDashboard");
    }

