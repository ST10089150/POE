using System.Collections.Generic;
using System;
using System.Linq;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;

public static class ClaimsDatabase
{
    // Use Entity Framework to interact with the database
    public static ClaimsContext Context = new ClaimsContext();

    // Add a claim
    public static void AddClaim(Claim claim)
    {
        Context.Claims.Add(claim);
        Context.SaveChanges();
    }

    // Get all claims with status 'Pending'
    public static List<Claim> GetPendingClaims()
    {
        return Context.Claims.Where(c => c.Status == "Pending").ToList();
    }

    // Get all claims by status
    public static List<Claim> GetClaimsByStatus(string status)
    {
        return Context.Claims.Where(c => c.Status == status).ToList();
    }

    // Update claim status
    public static void UpdateClaimStatus(int claimId, string status)
    {
        var claim = Context.Claims.FirstOrDefault(c => c.ClaimId == claimId);
        if (claim != null)
        {
            claim.Status = status;
            claim.LastUpdated = DateTime.Now;
            Context.SaveChanges();
        }
    }
}

}
