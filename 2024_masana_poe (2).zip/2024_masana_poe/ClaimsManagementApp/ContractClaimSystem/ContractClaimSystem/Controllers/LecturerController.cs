﻿using Microsoft.AspNetCore.Mvc;
using ContractClaimSystem.Data;
using ContractClaimSystem.Models;

public class LecturerController : Controller
{
    private readonly ApplicationDbContext _context;

    public LecturerController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult SubmitClaim()
    {
        return View();
    }

    [HttpPost]
    public IActionResult SubmitClaim(Claim claim)
    {
        if (ModelState.IsValid)
        {
            claim.TotalPayment = claim.HoursWorked * claim.HourlyRate;
            _context.Claims.Add(claim);
            _context.SaveChanges();
            return RedirectToAction("ClaimStatus");
        }
        return View(claim);
    }

    public IActionResult ClaimStatus()
    {
        var claims = _context.Claims.ToList();
        return View(claims);
    }
}
