﻿public class Claim
{
    public int ClaimId { get; set; }
    public string LecturerName { get; set; }
    public double HoursWorked { get; set; }
    public double HourlyRate { get; set; }
    public double TotalPayment { get; set; }
    public string Status { get; set; } = "Pending";
    public DateTime LastUpdated { get; set; } = DateTime.Now;
}
