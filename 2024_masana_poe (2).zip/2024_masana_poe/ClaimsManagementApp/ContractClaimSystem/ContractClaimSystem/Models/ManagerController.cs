﻿using Microsoft.AspNetCore.Mvc;

public class ManagerController : Controller
{
    private readonly ApplicationDbContext _context;

    public ManagerController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult PendingClaims()
    {
        var claims = _context.Claims.Where(c => c.Status == "Pending").ToList();
        return View(claims);
    }

    [HttpPost]
    public IActionResult ApproveClaim(int id)
    {
        var claim = _context.Claims.FirstOrDefault(c => c.ClaimId == id);
        if (claim != null)
        {
            claim.Status = "Approved";
            _context.SaveChanges();
        }
        return RedirectToAction("PendingClaims");
    }

    [HttpPost]
    public IActionResult RejectClaim(int id)
    {
        var claim = _context.Claims.FirstOrDefault(c => c.ClaimId == id);
        if (claim != null)
        {
            claim.Status = "Rejected";
            _context.SaveChanges();
        }
        return RedirectToAction("PendingClaims");
    }
}
