﻿public class Lecturer
{
    public int LecturerId { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }
}
