[SetUp]
public void Setup()
{
    var options = new DbContextOptionsBuilder<ClaimsContext>()
        .UseInMemoryDatabase(databaseName: "ClaimsTestDb")
        .Options;

    _context = new ClaimsContext(options);

    // Seed the database with a clean state
    _context.Database.EnsureDeleted();
    _context.Database.EnsureCreated();
}

