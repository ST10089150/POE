using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

public class ClaimsContext : DbContext
{
    public DbSet<Claim> Claims { get; set; }

    // Connection string to your SQL Server database
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=ClaimsManagement;Trusted_Connection=True;");
    }
}
