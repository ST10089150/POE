using System.Windows.Controls;

namespace ClaimsManagementApp
{
    public partial class TrackStatus : Page
    {
        public TrackStatus()
        {
            InitializeComponent();
            StatusListBox.ItemsSource = ClaimsDatabase.Claims;
        }
    }
}
