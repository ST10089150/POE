using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ClaimsManagementApp
{
    public partial class VerifyClaims : Page
    {
        public VerifyClaims()
        {
            InitializeComponent();
            ClaimsDataGrid.ItemsSource = ClaimsDatabase.GetPendingClaims();
        }

        private void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            var claimId = (int)((Button)sender).CommandParameter;
            ClaimsDatabase.UpdateClaimStatus(claimId, "Approved");
            ClaimsDataGrid.ItemsSource = ClaimsDatabase.GetPendingClaims();
        }

        private void RejectButton_Click(object sender, RoutedEventArgs e)
        {
            var claimId = (int)((Button)sender).CommandParameter;
            ClaimsDatabase.UpdateClaimStatus(claimId, "Rejected");
            ClaimsDataGrid.ItemsSource = ClaimsDatabase.GetPendingClaims();
        }
    }
}
