using Microsoft.Win32;
using System;
using System.Security.Claims;
using System.Windows;

namespace ClaimsManagementApp
{
    public partial class SubmitClaim : Page
    {
        private string uploadedFilePath;

        public SubmitClaim()
        {
            InitializeComponent();
        }

        private void UploadFileButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "PDF Files|*.pdf|Word Documents|*.docx|Excel Files|*.xlsx"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                uploadedFilePath = openFileDialog.FileName;
                UploadedFileName.Text = System.IO.Path.GetFileName(uploadedFilePath);
            }
        }

        private void SubmitClaimButton_Click(object sender, RoutedEventArgs e)
        {
            // Validate inputs
            if (string.IsNullOrEmpty(HoursWorkedTextBox.Text) || string.IsNullOrEmpty(HourlyRateTextBox.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            double hoursWorked = Convert.ToDouble(HoursWorkedTextBox.Text);
            double hourlyRate = Convert.ToDouble(HourlyRateTextBox.Text);
            string additionalNotes = NotesTextBox.Text;

            // Create and store the claim
            Claim newClaim = new Claim(ClaimsDatabase.Claims.Count + 1, "Lecturer Name", hoursWorked, hourlyRate, additionalNotes, uploadedFilePath);
            ClaimsDatabase.AddClaim(newClaim);

            MessageBox.Show("Claim submitted successfully!");
        }
    }
}
