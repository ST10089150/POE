﻿using System;

namespace ClaimsManagementApp
{
    internal class VerifyClaims : Uri
    {
    }
}