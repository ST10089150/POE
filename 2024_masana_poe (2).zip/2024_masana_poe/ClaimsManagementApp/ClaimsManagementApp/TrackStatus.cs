﻿using System;

namespace ClaimsManagementApp
{
    internal class TrackStatus : Uri
    {
    }
}