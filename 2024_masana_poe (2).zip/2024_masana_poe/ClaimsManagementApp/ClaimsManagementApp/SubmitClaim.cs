﻿using System;

namespace ClaimsManagementApp
{
    internal class SubmitClaim : Uri
    {
    }
}