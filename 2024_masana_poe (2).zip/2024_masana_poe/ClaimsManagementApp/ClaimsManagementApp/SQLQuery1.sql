CREATE TABLE Claims (
    ClaimId INT IDENTITY(1,1) PRIMARY KEY,
    LecturerName NVARCHAR(100),
    HoursWorked FLOAT,
    HourlyRate FLOAT,
    AdditionalNotes NVARCHAR(MAX),
    UploadedFilePath NVARCHAR(255),
    Status NVARCHAR(50) DEFAULT 'Pending',
    LastUpdated DATETIME DEFAULT GETDATE()
);
