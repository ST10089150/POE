using System;

public class Claim
{
    public int ClaimId { get; set; }
    public string LecturerName { get; set; }
    public double HoursWorked { get; set; }
    public double HourlyRate { get; set; }
    public string AdditionalNotes { get; set; }
    public string UploadedFilePath { get; set; }
    public string Status { get; set; } // Pending, Approved, Rejected
    public DateTime LastUpdated { get; set; }

    public Claim(int claimId, string lecturerName, double hoursWorked, double hourlyRate, string additionalNotes, string uploadedFilePath)
    {
        ClaimId = claimId;
        LecturerName = lecturerName;
        HoursWorked = hoursWorked;
        HourlyRate = hourlyRate;
        AdditionalNotes = additionalNotes;
        UploadedFilePath = uploadedFilePath;
        Status = "Pending";
        LastUpdated = DateTime.Now;
    }
}
public class Claim
{
    public int ClaimId { get; set; }
    public string LecturerName { get; set; }
    public double HoursWorked { get; set; }
    public double HourlyRate { get; set; }
    public string AdditionalNotes { get; set; }
    public string UploadedFilePath { get; set; }
    public string Status { get; set; }
    public DateTime LastUpdated { get; set; }
}
