// Approvals.xaml.cs
using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class Approvals : Window
    {
        public Approvals()
        {
            InitializeComponent();
        }

        private void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("This is a prototype - No functionality yet.");
        }
    }
}
