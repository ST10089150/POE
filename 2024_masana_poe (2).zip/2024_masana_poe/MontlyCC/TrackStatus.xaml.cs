// TrackStatus.xaml.cs
using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class TrackStatus : Window
    {
        public TrackStatus()
        {
            InitializeComponent();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
