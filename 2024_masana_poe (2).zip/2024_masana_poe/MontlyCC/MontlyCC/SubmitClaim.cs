﻿// SubmitClaim.xaml.cs
using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class SubmitClaim : Window
    {
        public SubmitClaim()
        {
          
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("This is a prototype - No functionality yet.");
        }
    }
}
