﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Event handler for "Submit Claim" button click
        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // Open the SubmitClaim window
            SubmitClaim submitClaimWindow = new SubmitClaim();
            submitClaimWindow.Show();
        }

        // Event handler for "Approvals" button click
        private void Approvals_Click(object sender, RoutedEventArgs e)
        {
            // Open the Approvals window
            Approvals approvalsWindow = new Approvals();
            approvalsWindow.Show();
        }

        // Event handler for "Track Status" button click
        private void TrackStatus_Click(object sender, RoutedEventArgs e)
        {
            // Open the TrackStatus window
            TrackStatus trackStatusWindow = new TrackStatus();
            trackStatusWindow.Show();
        }
    }
}
