﻿// Approvals.xaml.cs
using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class Approvals : Window
    {
        public Approvals()
        {
       
        }

        private void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("This is a prototype - No functionality yet.");
        }
    }
}
