﻿// TrackStatus.xaml.cs
using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class TrackStatus : Window
    {
        public TrackStatus()
        {
          
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
