// CoordinatorView.xaml.cs
using System.Linq;
using System.Security.Claims;
using System.Windows;
using System.Windows.Controls;
using ClaimManagementSystem.Models;

namespace ClaimManagementSystem.Views
{
    public partial class CoordinatorView : UserControl
    {
        private readonly ApplicationDbContext _context;

        public CoordinatorView()
        {
            InitializeComponent();
            _context = new ApplicationDbContext();

            // Load pending claims from the database
            LoadPendingClaims();
        }

        private void LoadPendingClaims()
        {
            // Retrieve pending claims from the database
            var pendingClaims = _context.Claims
                .Where(c => c.Status == "Pending")
                .ToList();

            // Bind claims to DataGrid
            ClaimsDataGrid.ItemsSource = pendingClaims;
        }

        private void ApproveClaimButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClaimsDataGrid.SelectedItem is Claim selectedClaim)
            {
                // Update status to Approved
                selectedClaim.Status = "Approved";

                // Save changes to the database
                _context.SaveChanges();

                // Refresh the pending claims list
                LoadPendingClaims();

                MessageBox.Show("Claim approved successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void RejectClaimButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClaimsDataGrid.SelectedItem is Claim selectedClaim)
            {
                // Update status to Rejected
                selectedClaim.Status = "Rejected";

                // Save changes to the database
                _context.SaveChanges();

                // Refresh the pending claims list
                LoadPendingClaims();

                MessageBox.Show("Claim rejected successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
