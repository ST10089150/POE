using System;
using System.Collections.Generic;

namespace ClaimManagementSystem.Models
{
    public class Claim
    {
        public int Id { get; set; }
        public int LecturerId { get; set; } // Foreign Key to Lecturer
        public DateTime DateSubmitted { get; set; } = DateTime.Now;
        public double HoursWorked { get; set; }
        public double HourlyRate { get; set; }
        public string Notes { get; set; }
        public string Status { get; set; } = "Pending"; // Default status
        public virtual ICollection<Document> Documents { get; set; } = new List<Document>();
    }
}