using System.Security.Claims;

namespace ClaimManagementSystem.Models
{
    public class Document
    {
        public int Id { get; set; }
        public int ClaimId { get; set; } // Foreign Key to Claim
        public string FileName { get; set; }
        public byte[] FileContent { get; set; }
        public virtual Claim Claim { get; set; }
    }
}