using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using ClaimManagementSystem.Models;
using System.Security.Claims;

public partial class LecturerForm : UserControl
{
    private readonly ApplicationDbContext _context;

    public LecturerForm()
    {
        InitializeComponent();
        _context = new ApplicationDbContext();
    }

    private void OnUploadButtonClick(object sender, RoutedEventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog
        {
            Filter = "PDF files (*.pdf)|*.pdf|Word documents (*.docx)|*.docx|Excel files (*.xlsx)|*.xlsx",
            Multiselect = false
        };

        if (openFileDialog.ShowDialog() == true)
        {
            var file = openFileDialog.FileName;
            var fileContent = File.ReadAllBytes(file);
            var document = new Document
            {
                FileName = Path.GetFileName(file),
                FileContent = fileContent
            };

            // Save the document to the database
            _context.Documents.Add(document);
            _context.SaveChanges();
        }
    }

    private void OnSubmitClaimClick(object sender, RoutedEventArgs e)
    {
        var claim = new Claim
        {
            LecturerId = 1, // Assume Lecturer ID is known or retrieved from a logged-in user
            HoursWorked = double.Parse(HoursWorkedTextBox.Text),
            HourlyRate = double.Parse(HourlyRateTextBox.Text),
            Notes = NotesTextBox.Text
        };

        _context.Claims.Add(claim);
        _context.SaveChanges();
    }
}
