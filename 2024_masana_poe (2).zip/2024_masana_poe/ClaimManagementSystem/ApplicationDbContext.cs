// Models/ApplicationDbContext.cs
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace ClaimManagementSystem.Models
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Claim> Claims { get; set; }
        public DbSet<Document> Documents { get; set; }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Using SQLite for simplicity; you could switch to SQL Server if needed
            optionsBuilder.UseSqlite("Data Source=claims.db");
        }
    }
}
