using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace ContractMonthlyClaimSystem
{
    public partial class LecturerView : Window
    {
        public LecturerView()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            if (decimal.TryParse(txtHours.Text, out decimal hours) && decimal.TryParse(txtRate.Text, out decimal rate))
            {
                txtTotal.Text = (hours * rate).ToString("C");
            }
            else
            {
                MessageBox.Show("Please enter valid numbers for hours and rate.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Documents (*.pdf;*.doc;*.xlsx)|*.pdf;*.doc;*.xlsx"
            };
            if (openFileDialog.ShowDialog() == true)
            {
                lblFileName.Text = Path.GetFileName(openFileDialog.FileName);
            }
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHours.Text) || string.IsNullOrWhiteSpace(txtRate.Text))
            {
                MessageBox.Show("Hours and Rate are required fields.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            MessageBox.Show("Claim submitted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
