using System;
using System.Windows.Forms;

namespace ContractMonthlyClaimSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmitClaim_Click(object sender, EventArgs e)
        {
            LecturerView lecturerView = new LecturerView();
            lecturerView.Show();
        }

        private void btnApprovals_Click(object sender, EventArgs e)
        {
            ManagerView managerView = new ManagerView();
            managerView.Show();
        }

        private void btnTrackStatus_Click(object sender, EventArgs e)
        {
            HRView hrView = new HRView();
            hrView.Show();
        }
    }
}
