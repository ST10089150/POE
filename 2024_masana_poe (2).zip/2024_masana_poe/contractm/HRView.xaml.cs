using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class HRView : Window
    {
        public HRView()
        {
            InitializeComponent();
        }

        private void btnGenerateReport_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Monthly report generated successfully!", "Report", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
