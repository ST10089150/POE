using System;
using System.Windows.Forms;

namespace ContractMonthlyClaimSystem
{
    public partial class ManagerView : Form
    {
        public ManagerView()
        {
            InitializeComponent();
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Claim Approved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Claim Rejected.", "Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
