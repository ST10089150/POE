using System;
using System.IO;
using System.Windows.Forms;

namespace ContractMonthlyClaimSystem
{
    public partial class LecturerView : Form
    {
        public LecturerView()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(txtHours.Text, out decimal hours) && decimal.TryParse(txtRate.Text, out decimal rate))
            {
                txtTotal.Text = (hours * rate).ToString("C");
            }
            else
            {
                MessageBox.Show("Please enter valid numbers for hours and rate.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string hours = txtHours.Text;
            string rate = txtRate.Text;
            string notes = txtNotes.Text;
            string filePath = lblFileName.Text;

            if (string.IsNullOrWhiteSpace(hours) || string.IsNullOrWhiteSpace(rate))
            {
                MessageBox.Show("Hours and Rate are required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show("Claim submitted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Documents (*.pdf;*.doc;*.xlsx)|*.pdf;*.doc;*.xlsx";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                lblFileName.Text = Path.GetFileName(openFileDialog.FileName);
            }
        }
    }
}
