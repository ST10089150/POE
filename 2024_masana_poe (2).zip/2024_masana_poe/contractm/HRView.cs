using System;
using System.Windows.Forms;

namespace ContractMonthlyClaimSystem
{
    public partial class HRView : Form
    {
        public HRView()
        {
            InitializeComponent();
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Monthly report generated successfully!", "Report", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
