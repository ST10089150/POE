using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class ManagerView : Window
    {
        public ManagerView()
        {
            InitializeComponent();
        }

        private void btnApprove_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claim Approved!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void btnReject_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claim Rejected.", "Status", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
