﻿using System;

namespace ContractMonthlyClaimSystem
{
    internal class HRView
    {
        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}