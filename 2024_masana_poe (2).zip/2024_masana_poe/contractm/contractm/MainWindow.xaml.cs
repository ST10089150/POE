﻿using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            LecturerView lecturerView = new LecturerView();
            lecturerView.Show();
        }

        private void btnApprovals_Click(object sender, RoutedEventArgs e)
        {
            ManagerView managerView = new ManagerView();
            managerView.Show();
        }

        private void btnTrackStatus_Click(object sender, RoutedEventArgs e)
        {
            HRView hrView = new HRView();
            hrView.Show();
        }
    }
}
