﻿using System;

namespace ContractMonthlyClaimSystem
{
    internal class LecturerView
    {
        public LecturerView()
        {
        }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}