﻿using System;

namespace ContractMonthlyClaimSystem
{
    internal class ManagerView
    {
        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}