using Moq;
using Xunit;
using LecturerClaimsApp.Controllers;
using LecturerClaimsApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using LecturerClaimsApp.Hubs;
using System.Threading.Tasks;

namespace LecturerClaimsApp.Tests
{
    public class ClaimsControllerTests
    {
        [Fact]
        public async Task Create_ValidClaim_ReturnsSuccessView()
        {
            // Arrange
            var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
            var controller = new ClaimsController(hubContextMock.Object);

            var claim = new ClaimModel
            {
                LecturerName = "John Doe",
                HoursWorked = 10,
                HourlyRate = 50,
                Notes = "Lecture on Software Development",
                Status = "Pending"
            };

            // Act
            var result = await controller.Create(claim, null);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("Success", viewResult.ViewName);
            Assert.True(controller.ModelState.IsValid);
        }

        [Fact]
        public async Task Create_InvalidModel_ReturnsSameViewWithErrors()
        {
            // Arrange
            var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
            var controller = new ClaimsController(hubContextMock.Object);
            controller.ModelState.AddModelError("Error", "Invalid data");

            var claim = new ClaimModel();

            // Act
            var result = await controller.Create(claim, null);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Null(viewResult.ViewName);
            Assert.False(controller.ModelState.IsValid);
        }
    }
}
[Fact]
public async Task Approve_Claim_ChangesStatusToApproved()
{
    // Arrange
    var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
    var controller = new ClaimsController(hubContextMock.Object);

    var claim = new ClaimModel
    {
        Id = 1,
        LecturerName = "John Doe",
        HoursWorked = 10,
        HourlyRate = 50,
        Status = "Pending"
    };

    ClaimRepository.AddClaim(claim);

    // Act
    var result = await controller.Approve(claim.Id);

    // Assert
    Assert.Equal("Approved", ClaimRepository.GetClaimById(claim.Id).Status);
}

[Fact]
public async Task Reject_Claim_ChangesStatusToRejected()
{
    // Arrange
    var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
    var controller = new ClaimsController(hubContextMock.Object);

    var claim = new ClaimModel
    {
        Id = 1,
        LecturerName = "Jane Smith",
        HoursWorked = 8,
        HourlyRate = 60,
        Status = "Pending"
    };

    ClaimRepository.AddClaim(claim);

    // Act
    var result = await controller.Reject(claim.Id);

    // Assert
    Assert.Equal("Rejected", ClaimRepository.GetClaimById(claim.Id).Status);
}

