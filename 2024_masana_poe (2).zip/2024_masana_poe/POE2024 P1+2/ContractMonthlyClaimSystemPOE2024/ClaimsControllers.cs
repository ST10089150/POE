using LecturerClaimsApp.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Security.Claims;
using System.Threading.Tasks;

namespace LecturerClaimsApp.Controllers
{
    public class ClaimsController : Controller
    {
        // GET: Claims/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Claims/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ClaimModel claim)
        {
            if (ModelState.IsValid)
            {
                // In a real-world application, you would save the claim to a database here.
                ViewBag.Message = "Claim successfully submitted!";
                return View("Success");
            }

            return View(claim);
        }
        // Save the file
        var fileName = Path.GetFileName(SupportingDocument.FileName);
        var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", fileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        SupportingDocument.CopyTo(stream);
                    }

// Set file details in claim
claim.FileName = fileName;
claim.FilePath = filePath;
                }

                // Save the claim (for now, we'll add it to the in-memory repository)
                ClaimRepository.AddClaim(claim);

// Redirect to success page
ViewBag.Message = "Claim successfully submitted!";
return View("Success");
            }

            return View(claim);
        }
    }
}
    }
}
using LecturerClaimsApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using LecturerClaimsApp.Hubs;

public class ClaimsController : Controller
{
    private readonly IHubContext<ClaimStatusHub> _hubContext;

    public ClaimsController(IHubContext<ClaimStatusHub> hubContext)
    {
        _hubContext = hubContext;
    }

    // Method to approve a claim
    [HttpPost]
    public async Task<IActionResult> Approve(int id)
    {
        var claim = ClaimRepository.GetClaimById(id);
        if (claim == null)
        {
            return NotFound();
        }

        claim.Status = "Approved";
        ClaimRepository.UpdateClaim(claim);

        // Notify all clients about status update
        await _hubContext.Clients.All.SendAsync("ReceiveClaimStatusUpdate", claim.Id, claim.Status);

        return RedirectToAction("PendingClaims", "Verification");
    }

    // Method to reject a claim
    [HttpPost]
    public async Task<IActionResult> Reject(int id)
    {
        var claim = ClaimRepository.GetClaimById(id);
        if (claim == null)
        {
            return NotFound();
        }

        claim.Status = "Rejected";
        ClaimRepository.UpdateClaim(claim);

        // Notify all clients about status update
        await _hubContext.Clients.All.SendAsync("ReceiveClaimStatusUpdate", claim.Id, claim.Status);

        return RedirectToAction("PendingClaims", "Verification");
    }
}
[HttpPost]
public async Task<IActionResult> Create(ClaimModel claim, IFormFile SupportingDocument)
{
    try
    {
        if (ModelState.IsValid)
        {
            // (File upload code goes here...)

            // Save the claim and send success message
            ClaimRepository.AddClaim(claim);
            ViewBag.Message = "Claim successfully submitted!";
            return View("Success");
        }
    }
    catch (Exception ex)
    {
        // Log the exception and show an error message to the user
        ModelState.AddModelError(string.Empty, "An error occurred while submitting the claim. Please try again.");
    }

    return View(claim);
}
[HttpPost]
public async Task<IActionResult> Create(ClaimModel claim, IFormFile SupportingDocument)
{
    try
    {
        if (ModelState.IsValid)
        {
            // File upload and claim creation logic here...

            ClaimRepository.AddClaim(claim);
            ViewBag.Message = "Claim successfully submitted!";
            return View("Success");
        }
        else
        {
            return View(claim); // Return same view with validation errors
        }
    }
    catch (Exception ex)
    {
        // Log the error and show an error message to the user
        ModelState.AddModelError(string.Empty, "An error occurred while submitting the claim. Please try again.");
        return View(claim);
    }
}

[HttpPost]
public async Task<IActionResult> Approve(int id)
{
    try
    {
        var claim = ClaimRepository.GetClaimById(id);
        if (claim == null) return NotFound();

        claim.Status = "Approved";
        ClaimRepository.UpdateClaim(claim);

        await _hubContext.Clients.All.SendAsync("ReceiveClaimStatusUpdate", claim.Id, claim.Status);

        return RedirectToAction("PendingClaims", "Verification");
    }
    catch (Exception ex)
    {
        // Log error and return a meaningful message
        return StatusCode(500, "An error occurred while approving the claim.");
    }
}

