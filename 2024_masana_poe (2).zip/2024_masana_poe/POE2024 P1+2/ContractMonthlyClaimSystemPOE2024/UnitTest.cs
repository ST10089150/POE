using Moq;
using Xunit;
using LecturerClaimsApp.Controllers;
using LecturerClaimsApp.Models;
using LecturerClaimsApp.Hubs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using System.IO;
using System.Threading.Tasks;
using System;

namespace LecturerClaimsApp.Tests
{
    public class UnitTest
    {
        // Test Claim Submission
        [Fact]
        public async Task Create_ValidClaim_ReturnsSuccessView()
        {
            // Arrange
            var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
            var controller = new ClaimsController(hubContextMock.Object);

            var claim = new ClaimModel
            {
                LecturerName = "John Doe",
                HoursWorked = 10,
                HourlyRate = 50,
                Notes = "Lecture on Software Development",
                Status = "Pending"
            };

            // Act
            var result = await controller.Create(claim, null);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("Success", viewResult.ViewName);
            Assert.True(controller.ModelState.IsValid);
        }

        // Test Claim Submission with Invalid Model
        [Fact]
        public async Task Create_InvalidModel_ReturnsSameViewWithErrors()
        {
            // Arrange
            var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
            var controller = new ClaimsController(hubContextMock.Object);
            controller.ModelState.AddModelError("Error", "Invalid data");

            var claim = new ClaimModel(); // Empty or invalid claim

            // Act
            var result = await controller.Create(claim, null);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Null(viewResult.ViewName); // Returns the same view
            Assert.False(controller.ModelState.IsValid);
        }

        // Test File Upload
        [Fact]
        public async Task Create_WithValidFileUpload_ReturnsSuccess()
        {
            // Arrange
            var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
            var controller = new ClaimsController(hubContextMock.Object);

            var claim = new ClaimModel
            {
                LecturerName = "John Doe",
                HoursWorked = 10,
                HourlyRate = 50,
                Notes = "Lecture on Software Development",
                Status = "Pending"
            };

            // Simulate file upload
            var fileMock = new Mock<IFormFile>();
            var content = "File content";
            var fileName = "supporting_document.pdf";
            var memoryStream = new MemoryStream();
            var writer = new StreamWriter(memoryStream);
            writer.Write(content);
            writer.Flush();
            memoryStream.Position = 0;

            fileMock.Setup(_ => _.OpenReadStream()).Returns(memoryStream);
            fileMock.Setup(_ => _.FileName).Returns(fileName);
            fileMock.Setup(_ => _.Length).Returns(memoryStream.Length);

            // Act
            var result = await controller.Create(claim, fileMock.Object);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            Assert.Equal("Success", viewResult.ViewName);
            Assert.True(controller.ModelState.IsValid);
        }

        // Test Approving a Claim
        [Fact]
        public async Task Approve_Claim_ChangesStatusToApproved()
        {
            // Arrange
            var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
            var controller = new ClaimsController(hubContextMock.Object);

            var claim = new ClaimModel
            {
                Id = 1,
                LecturerName = "John Doe",
                HoursWorked = 10,
                HourlyRate = 50,
                Status = "Pending"
            };

            ClaimRepository.AddClaim(claim);

            // Act
            var result = await controller.Approve(claim.Id);

            // Assert
            Assert.Equal("Approved", ClaimRepository.GetClaimById(claim.Id).Status);
        }

        // Test Rejecting a Claim
        [Fact]
        public async Task Reject_Claim_ChangesStatusToRejected()
        {
            // Arrange
            var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
            var controller = new ClaimsController(hubContextMock.Object);

            var claim = new ClaimModel
            {
                Id = 2,
                LecturerName = "Jane Smith",
                HoursWorked = 8,
                HourlyRate = 60,
                Status = "Pending"
            };

            ClaimRepository.AddClaim(claim);

            // Act
            var result = await controller.Reject(claim.Id);

            // Assert
            Assert.Equal("Rejected", ClaimRepository.GetClaimById(claim.Id).Status);
        }

        // Test Handling Errors in Claim Submission
        [Fact]
        public async Task Create_ThrowsException_ShowsErrorMessage()
        {
            // Arrange
            var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
            var controller = new ClaimsController(hubContextMock.Object);

            var claim = new ClaimModel
            {
                LecturerName = "John Doe",
                HoursWorked = 10,
                HourlyRate = 50,
                Notes = "Lecture on Software Development",
                Status = "Pending"
            };

            // Simulate an exception
            var exception = new Exception("Database failure");

            // Act and Assert
            var result = await Assert.ThrowsAsync<Exception>(() => controller.Create(claim, null));
            Assert.Equal("Database failure", result.Message);
        }

        // Test Approving a Non-existent Claim
        [Fact]
        public async Task Approve_NonExistentClaim_ReturnsNotFound()
        {
            // Arrange
            var hubContextMock = new Mock<IHubContext<ClaimStatusHub>>();
            var controller = new ClaimsController(hubContextMock.Object);

            // Act
            var result = await controller.Approve(999); // Non-existent claim

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }
    }
}
