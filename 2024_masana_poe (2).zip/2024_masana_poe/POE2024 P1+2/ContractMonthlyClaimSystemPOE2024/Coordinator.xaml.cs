using System.Collections.ObjectModel;
using System.Windows;

namespace ContractMonthlyClaimSystem
{
    public partial class Coordinator : Window
    {
        public class PendingClaim
        {
            public int ClaimID { get; set; }
            public string Lecturer { get; set; }
            public string DateSubmitted { get; set; }
            public string Status { get; set; }
        }

        public ObservableCollection<PendingClaim> PendingClaims { get; set; }

        public Coordinator()
        {
            InitializeComponent();

            // Sample data for pending claims
            PendingClaims = new ObservableCollection<PendingClaim>
            {
                new PendingClaim { ClaimID = 12345, Lecturer = "John Doe", DateSubmitted = "2024-08-15", Status = "Pending" },
                new PendingClaim { ClaimID = 12346, Lecturer = "Jane Smith", DateSubmitted = "2024-07-14", Status = "Pending" }
            };

            // Bind data to DataGrid
            PendingClaimsDataGrid.ItemsSource = PendingClaims;
        }

        private void ApproveBtn_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claim Approved.");
        }

        private void RejectBtn_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Claim Rejected.");
        }

        private void ViewDetailsBtn_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Viewing claim details.");
        }
    }
}
