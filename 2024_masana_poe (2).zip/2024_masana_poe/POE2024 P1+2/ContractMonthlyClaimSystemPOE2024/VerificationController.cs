using LecturerClaimsApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace LecturerClaimsApp.Controllers
{
    public class VerificationController : Controller
    {
        // GET: Verification/PendingClaims
        public IActionResult PendingClaims()
        {
            var pendingClaims = ClaimRepository.GetPendingClaims();
            return View(pendingClaims);
        }

        // POST: Verification/Approve
        [HttpPost]
        public IActionResult Approve(int id)
        {
            ClaimRepository.ApproveClaim(id);
            return RedirectToAction("PendingClaims");
        }

        // POST: Verification/Reject
        [HttpPost]
        public IActionResult Reject(int id)
        {
            ClaimRepository.RejectClaim(id);
            return RedirectToAction("PendingClaims");
        }
    }
}
