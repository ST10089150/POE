using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace LecturerClaimsApp.Hubs
{
    public class ClaimStatusHub : Hub
    {
        // Method to send real-time status update to clients
        public async Task UpdateClaimStatus(int claimId, string status)
        {
            await Clients.All.SendAsync("ReceiveClaimStatusUpdate", claimId, status);
        }
    }
}
