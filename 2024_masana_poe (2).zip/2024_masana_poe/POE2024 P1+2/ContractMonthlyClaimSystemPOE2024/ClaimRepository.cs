using System.Collections.Generic;
using System.Linq;

namespace LecturerClaimsApp.Models
{
    public static class ClaimRepository
    {
        private static List<ClaimModel> claims = new List<ClaimModel>();

        // Add a new claim to the repository
        public static void AddClaim(ClaimModel claim)
        {
            claim.Id = claims.Count + 1;
            claims.Add(claim);
        }

        // Get all claims
        public static List<ClaimModel> GetAllClaims()
        {
            return claims;
        }

        // Get pending claims
        public static List<ClaimModel> GetPendingClaims()
        {
            return claims.Where(c => c.Status == "Pending").ToList();
        }

        // Approve a claim by id
        public static void ApproveClaim(int id)
        {
            var claim = claims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.Status = "Approved";
            }
        }

        // Reject a claim by id
        public static void RejectClaim(int id)
        {
            var claim = claims.FirstOrDefault(c => c.Id == id);
            if (claim != null)
            {
                claim.Status = "Rejected";
            }
        }
    }
}
